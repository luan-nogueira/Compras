// IMPORTAÇÃO DO FIREBASE (CDN)
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { 
    getFirestore, 
    collection, 
    addDoc, 
    getDocs, 
    updateDoc, 
    deleteDoc, 
    doc, 
    query, 
    where, 
    orderBy,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

// CONFIGURAÇÃO DO FIREBASE
// IMPORTANTE: Substitua os valores abaixo pelas suas credenciais do Firebase Console
const firebaseConfig = {
    apiKey: "SUA_API_KEY",
    authDomain: "SEU_PROJETO.firebaseapp.com",
    projectId: "SEU_PROJETO_ID",
    storageBucket: "SEU_PROJETO.appspot.com",
    messagingSenderId: "SEU_SENDER_ID",
    appId: "SEU_APP_ID"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const comprasCol = collection(db, "compras");

// ESTADO DA APLICAÇÃO
let currentItems = [];
let isEditing = false;
let editId = null;

// ELEMENTOS DO DOM
const productForm = document.getElementById('productForm');
const productsList = document.getElementById('productsList');
const filterMonth = document.getElementById('filterMonth');
const filterMonthDashboard = document.getElementById('filterMonthDashboard');
const filterCategory = document.getElementById('filterCategory');
const filterStatus = document.getElementById('filterStatus');
const btnCopyNextMonth = document.getElementById('btnCopyNextMonth');

// INICIALIZAÇÃO
document.addEventListener('DOMContentLoaded', () => {
    setupMonthFilters();
    listenToData();
});

// CONFIGURAR FILTROS DE MÊS (Atual e próximos)
function setupMonthFilters() {
    const now = new Date();
    const currentMonthStr = now.toISOString().slice(0, 7); // YYYY-MM
    
    // Preencher selects de filtro
    const months = [];
    for(let i = -3; i <= 6; i++) {
        const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
        months.push(d.toISOString().slice(0, 7));
    }

    const options = months.map(m => `<option value="${m}" ${m === currentMonthStr ? 'selected' : ''}>${m}</option>`).join('');
    filterMonth.innerHTML = options;
    filterMonthDashboard.innerHTML = options;
    
    // Definir valor padrão no formulário
    document.getElementById('mesReferencia').value = currentMonthStr;
}

// ESCUTAR DADOS EM TEMPO REAL
function listenToData() {
    onSnapshot(query(comprasCol, orderBy("dataCriacao", "desc")), (snapshot) => {
        currentItems = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        render();
    });
}

// RENDERIZAÇÃO GERAL
function render() {
    const month = filterMonth.value;
    const category = filterCategory.value;
    const status = filterStatus.value;

    // Filtrar itens para a lista
    const filtered = currentItems.filter(item => {
        const matchMonth = item.mesReferencia === month;
        const matchCat = category === 'all' || item.categoria === category;
        const matchStatus = status === 'all' || item.status === status;
        return matchMonth && matchCat && matchStatus;
    });

    renderTable(filtered);
    updateDashboard(currentItems.filter(item => item.mesReferencia === filterMonthDashboard.value));
}

// RENDERIZAR TABELA
function renderTable(items) {
    productsList.innerHTML = items.map(item => `
        <tr>
            <td>
                <span class="status-badge ${item.status.toLowerCase()}">${item.status}</span>
            </td>
            <td>
                <strong>${item.nome}</strong>
                ${item.observacao ? `<br><small style="color: #64748b">${item.observacao}</small>` : ''}
            </td>
            <td>${item.categoria}</td>
            <td>${item.quantidade} ${item.unidade}</td>
            <td>R$ ${Number(item.valor).toFixed(2)}</td>
            <td><strong>R$ ${(item.quantidade * item.valor).toFixed(2)}</strong></td>
            <td>
                <div class="actions">
                    <button onclick="toggleStatus('${item.id}', '${item.status}')" class="btn-icon btn-check" title="Alternar Status">
                        <i class="fas ${item.status === 'Comprado' ? 'fa-undo' : 'fa-check'}"></i>
                    </button>
                    <button onclick="editItem('${item.id}')" class="btn-icon btn-edit" title="Editar">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button onclick="deleteItem('${item.id}')" class="btn-icon btn-delete" title="Excluir">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    if (items.length === 0) {
        productsList.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 2rem;">Nenhum item encontrado para este mês.</td></tr>';
    }
}

// ATUALIZAR DASHBOARD
function updateDashboard(items) {
    const totalPrevisto = items.reduce((acc, item) => acc + (item.quantidade * item.valor), 0);
    const totalComprado = items.filter(i => i.status === 'Comprado').reduce((acc, item) => acc + (item.quantidade * item.valor), 0);
    const totalPendente = totalPrevisto - totalComprado;

    // Categoria com maior gasto
    const catGasto = {};
    items.forEach(item => {
        catGasto[item.categoria] = (catGasto[item.categoria] || 0) + (item.quantidade * item.valor);
    });
    const maiorCat = Object.entries(catGasto).sort((a, b) => b[1] - a[1])[0];

    document.getElementById('totalPrevisto').innerText = `R$ ${totalPrevisto.toFixed(2)}`;
    document.getElementById('totalComprado').innerText = `R$ ${totalComprado.toFixed(2)}`;
    document.getElementById('totalPendente').innerText = `R$ ${totalPendente.toFixed(2)}`;
    document.getElementById('maiorGastoCategoria').innerText = maiorCat ? maiorCat[0] : '-';
}

// SALVAR / EDITAR ITEM
productForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const data = {
        nome: document.getElementById('nome').value,
        categoria: document.getElementById('categoria').value,
        quantidade: Number(document.getElementById('quantidade').value),
        unidade: document.getElementById('unidade').value,
        valor: Number(document.getElementById('valor').value),
        mesReferencia: document.getElementById('mesReferencia').value,
        status: document.getElementById('status').value,
        observacao: document.getElementById('observacao').value,
        dataCriacao: new Date().toISOString()
    };

    try {
        if (isEditing) {
            await updateDoc(doc(db, "compras", editId), data);
            resetForm();
        } else {
            await addDoc(comprasCol, data);
            productForm.reset();
            setupMonthFilters(); // Resetar para mês atual
        }
    } catch (error) {
        console.error("Erro ao salvar:", error);
        alert("Erro ao salvar os dados no Firebase.");
    }
});

// ALTERNAR STATUS
window.toggleStatus = async (id, currentStatus) => {
    const newStatus = currentStatus === 'Pendente' ? 'Comprado' : 'Pendente';
    await updateDoc(doc(db, "compras", id), { status: newStatus });
};

// EDITAR ITEM
window.editItem = (id) => {
    const item = currentItems.find(i => i.id === id);
    if (!item) return;

    document.getElementById('productId').value = item.id;
    document.getElementById('nome').value = item.nome;
    document.getElementById('categoria').value = item.categoria;
    document.getElementById('quantidade').value = item.quantidade;
    document.getElementById('unidade').value = item.unidade;
    document.getElementById('valor').value = item.valor;
    document.getElementById('mesReferencia').value = item.mesReferencia;
    document.getElementById('status').value = item.status;
    document.getElementById('observacao').value = item.observacao || '';

    isEditing = true;
    editId = id;
    document.getElementById('btnSave').innerText = 'Atualizar Produto';
    document.getElementById('btnCancel').style.display = 'inline-block';
    document.getElementById('cadastro').scrollIntoView({ behavior: 'smooth' });
};

// EXCLUIR ITEM
window.deleteItem = async (id) => {
    if (confirm('Tem certeza que deseja excluir este item?')) {
        await deleteDoc(doc(db, "compras", id));
    }
};

// CANCELAR EDIÇÃO
document.getElementById('btnCancel').addEventListener('click', resetForm);

function resetForm() {
    productForm.reset();
    isEditing = false;
    editId = null;
    document.getElementById('btnSave').innerText = 'Salvar Produto';
    document.getElementById('btnCancel').style.display = 'none';
    setupMonthFilters();
}

// COPIAR PARA PRÓXIMO MÊS
btnCopyNextMonth.addEventListener('click', async () => {
    const currentMonth = filterMonth.value;
    const itemsToCopy = currentItems.filter(item => item.mesReferencia === currentMonth);

    if (itemsToCopy.length === 0) {
        alert('Não há itens neste mês para copiar.');
        return;
    }

    // Calcular próximo mês
    const [year, month] = currentMonth.split('-').map(Number);
    const nextDate = new Date(year, month, 1); // month já é 0-indexed para o próximo mês real
    const nextMonthStr = nextDate.toISOString().slice(0, 7);

    if (confirm(`Deseja copiar ${itemsToCopy.length} itens para o mês ${nextMonthStr}?`)) {
        try {
            for (const item of itemsToCopy) {
                const { id, dataCriacao, ...rest } = item;
                await addDoc(comprasCol, {
                    ...rest,
                    mesReferencia: nextMonthStr,
                    status: 'Pendente',
                    dataCriacao: new Date().toISOString()
                });
            }
            alert('Itens copiados com sucesso!');
            filterMonth.value = nextMonthStr;
            render();
        } catch (error) {
            console.error("Erro ao copiar:", error);
            alert("Erro ao copiar itens.");
        }
    }
});

// EVENTOS DE FILTRO
filterMonth.addEventListener('change', render);
filterMonthDashboard.addEventListener('change', render);
filterCategory.addEventListener('change', render);
filterStatus.addEventListener('change', render);
